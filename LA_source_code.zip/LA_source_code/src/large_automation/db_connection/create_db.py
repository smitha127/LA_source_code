import sqlite3
import json

conn = sqlite3.connect("C:\\Muraghendra\\LargeAuto_Sqlite\\LeanKit_Automation.db")
c = conn.cursor()


def create_table():
    c.execute("CREATE TABLE IF NOT EXISTS CardDetails(CON_DP No integer PRIMARY KEY, Type TEXT NOT NULL, Part_NO TEXT NOT NULL, Part_Name TEXT NOT NULL, Priority TEXT, NoOf_Line_Items TEXT NOT NULL, Engineer TEXT, Tech_Reviewer TEXT,Start_Date TEXT, Status TEXT, Current_Lane_ID TEXT, CurrentLane TEXT, CurrentLane_TRT TEXT, Overall_TRT TEXT, Engine TEXT, SCU TEXT, ForumPass_Link TEXT, LeanKit_Card_ID TEXT, QTY integer, NC_Type TEXT , Specialist_Loop TEXT NOT NULL, Estimated_Closure_Date TEXT)")

# def retrive_data():
#     c.execute('SELECT * FROM CardDetails')

class Create_DB:

    def data_entry(json_data):
        y={}
        y = json.loads(json_data)
        print("-->", y["card_title"])

        card_title = str(y["card_title"])
        engineNo = y["engineNo"]
        partNo = y["partNo"]
        customId_ConsessionNo = y["customId_ConsessionNo"]
        plannedFinish = y["plannedFinish"]
        externalLinks = y["externalLinks"]
        card_ID = y["card_ID"]
        lane_ID = y["lane_ID"]
        lane_ClassType = y["lane_ClassType"]
        priority = y["priority"]
        card_size = y["card_size"]
        card_type = y["card_type"]
        #c.execute("INSERT INTO CardDetails VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)", (card_title, engineNo, partNo, customId_ConsessionNo,plannedFinish, externalLinks, card_ID,lane_ID,lane_ClassType,priority, card_size,card_type))
        c.execute("INSERT INTO CardDetails (CON_DP, Type, Part_NO, Part_Name, Priority, NoOf_Line_Items, Engineer, Tech_Reviewer,"
                  "Start_Date, Status, Current_Lane_ID, CurrentLane, CurrentLane_TRT, Overall_TRT, Engine, "
                  "SCU, ForumPass_Link, LeanKit_Card_ID, QTY , NC_Type, Specialist_Loop, Estimated_Closure_Date) VALUES (?, ?, ?, ?,?, ?, ?, ?,?, ?, ?, ?,?, ?, ?, ?,?, ?, ?, ?,?,?)",
                  (customId_ConsessionNo, lane_ClassType, partNo,"", priority, "", "", "", "", "", lane_ID, "","", "", engineNo, "", externalLinks, card_ID, "", "", "", plannedFinish ))
        #
        # {"card_title": card_title, "engineNo": engine_no, "partNo": eng_part_no,
        #  "customId_ConsessionNo": custom_id_consession_no,
        #  "plannedFinish": planned_finish, "externalLinks": external_links,
        #  "card_ID": card_id,
        #  "lane_ID": lane_id, "lane_ClassType": lane_class_type,
        #  "priority": priority,
        #  "card_size": card_size, "card_type": card_type}
        conn.commit()
        #c.close()
        #conn.close()


create_table()
#retrive_data()
#data_entry()

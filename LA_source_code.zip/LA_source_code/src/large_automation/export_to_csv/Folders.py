import os


class Folders(object):
    def  create_folder(conc_no):
	
       #change directory, providing the path to save folders
        os.chdir('C:\\Users\\1015814\\Desktop\\OpenFolder')

        # print current working directory
        print(os.getcwd())
		
		# Function for creating subfolders
        os.mkdir(str(conc_no))
        subfolder_names = ['Input', 'WIP', 'Deliverables']
        for subfolder_name in subfolder_names:
            os.makedirs(os.path.join(str(conc_no), subfolder_name))

        os.chdir('C:\\Users\\1015814\\Desktop\\OpenFolder\\'+str(conc_no))

        subfolder_trs = ['For Review', 'Under Review']
        for subfolder_tr in subfolder_trs:
            os.makedirs(os.path.join('TecnicalReview', subfolder_tr))

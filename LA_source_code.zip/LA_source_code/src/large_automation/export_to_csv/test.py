import pandas as pd

df = pd.read_csv('C:\\Users\\1015814\\Desktop\CardDetails\\card_details.csv')
mylist = df['Conc No'].tolist()
print("list", mylist)

if 'eCon 211138341' not in mylist:
    print("Available")

import csv
import os
import json

class CopyToCsv:

    # Creating a csv file and  sending json object into csv
    def copy_row_to_csv(self, conc_info):

        try:
            #  converting consumer object into json
            conc_dict = json.loads(conc_info)

            row = [conc_dict['card_title'], conc_dict['engineNo'],conc_dict['partNo'],conc_dict['customId_ConsessionNo'],
                   conc_dict['plannedFinish'],conc_dict['externalLinks'],conc_dict['card_ID'],conc_dict['lane_ID'],
                   conc_dict['lane_ClassType'],conc_dict['priority'],conc_dict['card_size'],conc_dict['card_type']]
            print(row)
            with open('C:\\Users\\1023816\\Desktop\\CardDetails\\card_details.csv', 'a', newline='') as csvFile:
                writer = csv.writer(csvFile)
                writer.writerow(row)

            csvFile.close()

        except Exception as e:
            print(e)
            print("Exception is inside copy_row_to_csv")





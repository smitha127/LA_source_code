import requests
from configparser import ConfigParser

# Fetching details of all information present in Leankit_Config.config
class Config:

    # Instantiating class variables
    def __init__(self):
        print("inti")
        self.parser = ConfigParser()
        self.parser.read('Leankit_Config.config')
        print(self.parser.read('Leankit_Config.config'))

    # Gives browser information
    def headers(self):
        agent = self.parser.get('database_config', 'head')
        return agent

    # Gives user credential to access Leankit
    def credentials(self):
        username = self.parser.get('database_config', 'username')
        password = self.parser.get('database_config', 'password')
        login_data = {"userName": username, "password": password, 'Login': "Log in"}
        return login_data

    # Gives active session
    def session(self):
        sess = requests.session()
        return sess

    # Gives all url's to access leankit concession boards
    def url_store(self):
        url1 = self.parser.get('database_config', 'url')
        url2 = self.parser.get('database_config','url2')
        url3 = self.parser.get('database_config', 'url3')
        url4 = self.parser.get('database_config', 'url4')
        url5 = self.parser.get('database_config', 'url5')
        return url1, url2, url3, url4, url5

    # Gives concession board identities
    def boards(self):
        boards_info = self.parser.get('database_config','board_no')
        return boards_info

obj = Config()


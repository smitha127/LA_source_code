from large_automation.main.Leankit_Web_Scraping import WebScraping

# Obtaining Information from Leankit, validating it and pushing it into queue
WebScraping().executor()

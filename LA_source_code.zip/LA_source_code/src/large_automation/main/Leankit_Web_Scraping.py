import requests
from bs4 import BeautifulSoup
import json
import sys
import large_automation.main.Read_Leankit_Config
from large_automation.rabbitmq.Card_Producer import Producer
from large_automation.validation.Validate_Conc_Number import Validate



# Obtaining data from Leankit
class WebScraping():

    # Instantiating class variables
    def __init__(self):
        self.head = large_automation.main.Read_Leankit_Config.obj.headers()
        self.cred = large_automation.main.Read_Leankit_Config.obj.credentials()
        self.url1 = large_automation.main.Read_Leankit_Config.obj.url_store()
        # self.board_info = large_automation.main.Read_Leankit_Config.obj.boards()
        self.conc_list = Validate.validate_conc_number()
        print("List", self.conc_list)

    # Accessing Leankit url's during active session
    def executor(self):

        # Login to Leankit
        try:
            with requests.session() as sess:
                url_1 = self.url1[0]
                header = json.loads(self.head.replace("'", "\""))
                req = sess.get(url_1, headers=header)
                url_2 = self.url1[1]
                req = sess.get(url_2)

                # Calling information from concession boards
                WebScraping.boards(self)
        except Exception as e:
            print(e)
            lineno = sys.exc_info()[-1].tb_lineno
            print("Error in line: "+ str(lineno))

    # Fetching information in concession boards
    def boards(self):

        # Fetching information from specific concession boards using Beautiful Soup
        try:
            with requests.session() as sess:
                url_1 = self.url1[0]
                header = json.loads(self.head.replace("'", "\""))
                req = sess.post(url_1, data=self.cred, headers=header)
                # board_no=['147190646','147194741','147182241','147182798','147190758','147190433','147190864']
                board_no = ['147190646', '147194741']
                # board_no = self.board_info
                url_3 = self.url1[2]
                url_4 = self.url1[3]

                for i in board_no:
                    req = sess.get(url_3 + i + url_4 + i + "")
                    soup1 = BeautifulSoup(req.content, 'lxml')
                    cards1 = soup1.find("p")
                    cards2 = cards1.text
                    list_of_cards = []
                    card_nos = json.loads(cards2)
                    card_info = card_nos['cards']
                    for no_of_cards in range(len(card_info)):
                        list_of_cards.append(card_nos['cards'][no_of_cards]['id'])

                    # Calling information from all cards from each concession board
                    WebScraping.cards(self, list_of_cards)
        except Exception as e:
            print(e)
            line_no = sys.exc_info()[-1].tb_lineno
            print("Error in line: "+ str(line_no))

    # Fetching information from 'PENDING TO BE LAUNCHED' cards form each concession board
    def cards(self, li):

        # Identifying attributes present in each card in specific concession board
        try:
            with requests.session() as sess:
                url_1 = self.url1[0]
                header = json.loads(self.head.replace("'", "\""))
                req = sess.post(url_1, data=self.cred, headers=header)
                list_of_cards = li
                url_5 = self.url1[4]

                for i in list_of_cards:
                    try:
                        req = sess.get(url_5 + i + "?id=" + i + "")
                        soup = BeautifulSoup(req.content, 'lxml')
                        card = soup.findAll(text=True)
                        if len(card) > 1:
                            card = card[0] + card[len(card) - 1]
                        elif len(card) == 1:
                            card = card[0]
                        card_details = json.loads(card)
                        planned_finish = card_details['plannedFinish']
                        external_links = card_details['externalLinks']
                        custom_id_consession_no = card_details['customId']['value']

                        # Identifying cards to select: Only those cards that have 'external links' present
                        if (external_links != []):
                            external_links = card_details['externalLinks'][0]['url']
                        elif (external_links == None):
                            external_links = card_details['externalLinks'][0]['label']
                        elif (external_links != []):
                            external_links = soup.findAll(text=True)[1]

                        card_id = card_details['id']
                        lane_id = card_details['lane']['id']
                        lane_class_type = card_details['lane']['laneClassType']
                        priority = card_details['priority']
                        card_size = card_details['size']
                        card_title = card_details['title']
                        card_title1 = card_title.split(" ")
                        engine_no = card_title1[0]
                        eng_part_no = str(card_title1[1:])
                        card_type = card_details['type']['title']

                        # Choosing cards that are in the 'PENDING TO BE LAUNCHED' lane
                        if lane_class_type == 'backlog':
                            card_details_data = {"card_title": card_title, "engineNo": engine_no, "partNo": eng_part_no,
                                                 "customId_ConsessionNo": custom_id_consession_no,
                                                 "plannedFinish": planned_finish, "externalLinks": external_links,
                                                 "card_ID": card_id,
                                                 "lane_ID": lane_id, "lane_ClassType": lane_class_type,
                                                 "priority": priority,
                                                 "card_size": card_size, "card_type": card_type}

                            print(card_details_data)

                            # Data Validation: Only if 'customId_ConsessionNo' is not present in 'card_details.csv', push the card to queue
                            if custom_id_consession_no not in self.conc_list:
                                prod_obj = Producer()

                                # Calling producer to push validated card details into queue
                                prod_obj.producer(card_details_data)
                    except:
                        pass

        except Exception as e:
            print(e)
            lineno = sys.exc_info()[-1].tb_lineno
            print("Error in line: "+ str(lineno))
import requests
from bs4 import BeautifulSoup
import json
import sys
import pandas as pd
import large_automation.main.Read_Leankit_Config
from large_automation.rabbitmq.Card_Producer import Producer
from large_automation.validation.Validate_Conc_Number import Validate
from large_automation.main.try2 import web_Scraping1
import lxml


class web_Scraping():

    def __init__(self):
        self.head = large_automation.main.Read_Leankit_Config.obj.headers()
        self.cred = large_automation.main.Read_Leankit_Config.obj.credentials()
        self.url1 = large_automation.main.Read_Leankit_Config.obj.url_store()

        self.conc_list = Validate.validate_conc_number(self)
        print("List", self.conc_list)

    def login(self):
        try:
            with requests.session() as s:
                card_details_from_boards = []

                url_1 = self.url1[0]
                header = json.loads(self.head.replace("'", "\""))
                credentials = self.cred
                r = s.get(url_1, headers=header)
                url_2 = self.url1[1]
                r = s.get(url_2)
                # card_details_from_boards.extend(Web_Scrapy.boards(self, r))
                web_Scraping.boards(self, r)
        except Exception as e:
            print(e)
            lineno = sys.exc_info()[-1].tb_lineno
            print("Error in line: "+ str(lineno))
        # print(card_details_from_boards)
        #return card_details_from_boards


# web_Scraping().executor()
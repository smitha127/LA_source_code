import requests
from bs4 import BeautifulSoup
import json
import sys
import pandas as pd
import large_automation.main.Read_Leankit_Config
from large_automation.rabbitmq.Card_Producer import Producer
from large_automation.validation.Validate_Conc_Number import Validate
import large_automation.main.try1
import lxml


class web_Scraping1():
    large_automation.main.try1.web_Scraping.login()
    def __init__(self):
        self.head = large_automation.main.Read_Leankit_Config.obj.headers()
        self.cred = large_automation.main.Read_Leankit_Config.obj.credentials()
        self.url1 = large_automation.main.Read_Leankit_Config.obj.url_store()

        self.conc_list = Validate.validate_conc_number(self)
        print("List", self.conc_list)

    def executor(self):


    # def executor(self):
    #     try:
    #         web_Scraping.login()
    #         # with requests.session() as s:
    #         #     card_details_from_boards = []
    #         #
    #         #     url_1 = self.url1[0]
    #         #     header = json.loads(self.head.replace("'", "\""))
    #         #     credentials = self.cred
    #         #     r = s.get(url_1, headers=header)
    #         #     url_2 = self.url1[1]
    #         #     r = s.get(url_2)
    #         #     # card_details_from_boards.extend(Web_Scrapy.boards(self, r))
    #         #     web_Scraping.boards(self, r)
    #     except Exception as e:
    #         print(e)
    #         lineno = sys.exc_info()[-1].tb_lineno
    #         print("Error in line: "+ str(lineno))
    #     # print(card_details_from_boards)
    #     #return card_details_from_boards


    def boards(self, r):
        try:
            with requests.session() as s:
                url_1 = self.url1[0]
                header = json.loads(self.head.replace("'", "\""))
                r = s.post(url_1, data=self.cred, headers=header)
                #board_no = ["123457855", "111137067", "106606106", "107600350"]
                # board_no=['147190646','147194741','147182241','147182798','147190758','147190433','147190864']
                # for i in board_no:
                #     print(i)
                board_no = ['147190646', '147194741']
                for item in board_no:
                    # print(board_no[item])
                    #large_automation.csv3.csv_sheet(item)
                    url_3 = self.url1[2]
                    url_4 = self.url1[3]
                    card_details_from_cards = []

                for i in board_no:
                    r = s.get(url_3 + i + url_4 + i + "")
                    soup1 = BeautifulSoup(r.content, 'lxml')
                    cards1 = soup1.find("p")
                    cards2 = cards1.text
                    listofcards = []
                    card_Nos = {}
                    card_Nos = json.loads(cards2)
                    asd = card_Nos['cards']
                    for i in range(len(asd)):
                        listofcards.append(card_Nos['cards'][i]['id'])

                    # card_details_from_cards.extend(Web_Scrapy.cards(self, listofcards))
                    web_Scraping1.cards(self, listofcards, i)
        except Exception as e:
            print(e)
            lineno = sys.exc_info()[-1].tb_lineno
            print("Error in line: "+ str(lineno))

        # print(card_title_list1)
        #return card_details_from_cards




    def cards(self, li, board_no):
        try:
            with requests.session() as s:
                url_1 = self.url1[0]
                header = json.loads(self.head.replace("'", "\""))
                r = s.post(url_1, data=self.cred, headers=header)
                listofcards = li
                url_5 = self.url1[4]

                for i in listofcards:
                    try:
                        r = s.get(url_5 + i + "?id=" + i + "")
                        soup = BeautifulSoup(r.content, 'lxml')
                        card = soup.findAll(text=True)
                        if len(card) > 1:
                            card = card[0] + card[len(card) - 1]
                        elif len(card) == 1:
                            card = card[0]
                        card_Details = json.loads(card)
                        card_body = soup.find('body')
                        plannedFinish = card_Details['plannedFinish']
                        externalLinks = card_Details['externalLinks']
                        customId_ConsessionNo = card_Details['customId']['value']
                        if (externalLinks != []):
                            externalLinks = card_Details['externalLinks'][0]['url']
                        elif (externalLinks == None):
                            externalLinks = card_Details['externalLinks'][0]['label']
                        elif (externalLinks != []):
                            externalLinks = soup.findAll(text=True)[1]
                        card_ID = card_Details['id']
                        lane_ID = card_Details['lane']['id']
                        lane_ClassType = card_Details['lane']['laneClassType']
                        lane_title = card_Details['lane']['title']
                        priority = card_Details['priority']
                        card_size = card_Details['size']
                        card_title = card_Details['title']
                        card_title1 = card_title.split(" ")
                        engineNo = card_title1[0]
                        engpartNo = str(card_title1[1:])
                        card_type = card_Details['type']['title']
                        # if card_ID == '147363278':
                        if lane_ClassType == 'backlog':
                            card_Details_data = {"card_title": card_title, "engineNo": engineNo, "partNo": engpartNo,
                                                 "customId_ConsessionNo": customId_ConsessionNo,
                                                 "plannedFinish": plannedFinish, "externalLinks": externalLinks,
                                                 "card_ID": card_ID,
                                                 "lane_ID": lane_ID, "lane_ClassType": lane_ClassType,
                                                 "priority": priority,
                                                 "card_size": card_size, "card_type": card_type}

                            print(card_Details_data)

                            if customId_ConsessionNo not in self.conc_list:
                                Producer.producer(self, card_Details_data)

                    except:
                        pass
                    # except Exception as ex:
                    #     print("Exception", ex)
                # print(card_title_list)

        except Exception as e:
            print(e)
            lineno = sys.exc_info()[-1].tb_lineno
            print("Error in line: "+ str(lineno))

        # print(card_title_list)
        #return card_title_list, engineNo_list,engpartNo_list,customId_ConsessionNo_list, plannedFinish_list,externalLinks_list,card_ID_list,lane_ID_list,lane_ClassType_list,priority_list,card_size_list,card_type_list



web_Scraping1().executor()








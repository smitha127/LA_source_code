import pandas as pd

# validating the conc No weather it is present in csv or not
class Validate:
    def validate_conc_number():
        df = pd.read_csv('C:\\Users\\1015814\\Desktop\CardDetails\\card_details.csv')
        conc_list = df['Conc No'].tolist()

        return conc_list
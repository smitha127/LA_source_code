import pika
import json

class Producer:
    def producer(self, card_details_data):
		# Converting object into json object
        json_message = json.dumps(card_details_data)
		
		# Blocking connection with rabbitmq, declaring queue & publishing queue & sending queues to consumers
        connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
        channel = connection.channel()
        channel.queue_declare(queue="cards1")
        channel.basic_publish(exchange='', routing_key='cards1', body=json_message)
        print("[x] Card Details are successfuly sent to queue")
        connection.close()

import pika
import json
from large_automation.export_to_csv.Copy_To_Csv import CopyToCsv
from large_automation.export_to_csv.Folders import Folders
from large_automation.db_connection.create_db import Create_DB

# Blocking Connection with rabbitmq
connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
channel = connection.channel()

# Declaring queue name
channel.queue_declare(queue='cards1')


# Declaring callback function to consume queues & Consumed queues are been written to CSV file & then folder structure creation i
def callback(ch, method, properties, body):

    print(" [x] Received %r"   +str(body))

    Create_DB.data_entry(body)
    var = CopyToCsv()
    var.copy_row_to_csv(body)
    print(var)
    if var is not None:
        print("Successful")
    else:
        print("Not successful.", str(body), "is not written into card_details.csv")
    conc_dict = json.loads(body)
    conc_no = conc_dict['customId_ConsessionNo']
    Folders.create_folder(conc_no)
	
	# channel is created to consume the queue

channel.basic_consume(queue='cards1', on_message_callback=callback, auto_ack=True)

print(' [*] Waiting for messages. To exit press CTRL+C')
channel.start_consuming()





